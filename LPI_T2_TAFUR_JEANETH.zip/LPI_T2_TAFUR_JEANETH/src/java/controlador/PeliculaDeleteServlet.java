/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.PeliculaDAO;
import dao.PeliculaDAOImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 * @author jtafu
 */
@WebServlet(name = "PeliculaDelete", urlPatterns = {"/PeliculaDelete"})
public class PeliculaDeleteServlet extends HttpServlet {
    
        @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
       PeliculaDAO dao = new PeliculaDAOImpl();
        dao.eliminar(id);
        response.sendRedirect("formularioPelicula");
        // processRequest(request, response);
    }

}
